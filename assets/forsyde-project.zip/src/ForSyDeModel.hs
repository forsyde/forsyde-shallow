module ForSyDeModel where

import ForSyDe.Shallow

adder = zipWithSY (+)